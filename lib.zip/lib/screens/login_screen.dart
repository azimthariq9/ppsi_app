import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../utils/app_colors.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {

  late TabController _tabController;

  // LOGIN
  final TextEditingController loginEmailController =
      TextEditingController();

  final TextEditingController loginPasswordController =
      TextEditingController();

  // REGISTER
  final TextEditingController regNamaController =
      TextEditingController();

  final TextEditingController regNikController =
      TextEditingController();

  final TextEditingController regEmailController =
      TextEditingController();

  final TextEditingController regPasswordController =
      TextEditingController();

  final TextEditingController regNoHpController =
      TextEditingController();

  final TextEditingController regAlamatController =
      TextEditingController();

  bool obscureLogin = true;
  bool obscureRegister = true;

  bool loadingLogin = false;
  bool loadingRegister = false;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(
      length: 2,
      vsync: this,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();

    loginEmailController.dispose();
    loginPasswordController.dispose();

    regNamaController.dispose();
    regNikController.dispose();
    regEmailController.dispose();
    regPasswordController.dispose();
    regNoHpController.dispose();
    regAlamatController.dispose();

    super.dispose();
  }

  // =========================================================
  // LOGIN
  // =========================================================

  Future<void> login() async {
    try {
      setState(() {
        loadingLogin = true;
      });

      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: loginEmailController.text.trim(),
        password: loginPasswordController.text.trim(),
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Login berhasil'),
        ),
      );

      // Cek role lalu arahkan ke dashboard yang sesuai
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .get();
        final role = userDoc.data()?['role'] ?? 'warga';
        if (!mounted) return;
        if (role == 'admin') {
          Navigator.pushReplacementNamed(context, '/admin');
        } else {
          Navigator.pushReplacementNamed(context, '/home');
        }
      } else {
        Navigator.pushReplacementNamed(context, '/home');
      }

    } on FirebaseAuthException catch (e) {

      // ignore: avoid_print
      print('LOGIN ERROR CODE: ${e.code} | MESSAGE: ${e.message}');

      String message = 'Terjadi kesalahan (${e.code})';

      if (e.code == 'user-not-found') {
        message = 'Email tidak ditemukan';
      }

      if (e.code == 'wrong-password') {
        message = 'Password salah';
      }

      // Firebase Auth versi terbaru menggabungkan user-not-found
      // dan wrong-password menjadi satu kode ini demi keamanan.
      if (e.code == 'invalid-credential' ||
          e.code == 'invalid-login-credentials') {
        message = 'Email atau password salah';
      }

      if (e.code == 'invalid-email') {
        message = 'Format email salah';
      }

      if (e.code == 'user-disabled') {
        message = 'Akun ini telah dinonaktifkan';
      }

      if (e.code == 'too-many-requests') {
        message = 'Terlalu banyak percobaan, coba lagi nanti';
      }

      if (e.code == 'network-request-failed') {
        message = 'Tidak ada koneksi internet';
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );

    } finally {
      setState(() {
        loadingLogin = false;
      });
    }
  }

  // =========================================================
  // REGISTER
  // =========================================================

  Future<void> register() async {
    try {
      setState(() {
        loadingRegister = true;
      });

      UserCredential credential =
          await FirebaseAuth.instance
              .createUserWithEmailAndPassword(
        email: regEmailController.text.trim(),
        password: regPasswordController.text.trim(),
      );

      await credential.user?.updateDisplayName(
        regNamaController.text.trim(),
      );

      // Simpan data user ke Firestore dengan role warga
      await FirebaseFirestore.instance
          .collection('users')
          .doc(credential.user!.uid)
          .set({
        'nama': regNamaController.text.trim(),
        'nik': regNikController.text.trim(),
        'email': regEmailController.text.trim(),
        'no_hp': regNoHpController.text.trim(),
        'alamat': regAlamatController.text.trim(),
        'role': 'warga',
        'created_at': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Register berhasil'),
        ),
      );

      _tabController.animateTo(0);

    } on FirebaseAuthException catch (e) {

      String message = 'Terjadi kesalahan';

      if (e.code == 'email-already-in-use') {
        message = 'Email sudah digunakan';
      }

      if (e.code == 'weak-password') {
        message = 'Password terlalu lemah';
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );

    } finally {
      setState(() {
        loadingRegister = false;
      });
    }
  }

  // =========================================================
  // UI
  // =========================================================

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: AppColors.bgGreen,

      body: SafeArea(
        child: Column(
          children: [

            // HEADER

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),

              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF1B4332),
                    Color(0xFF2D6A4F),
                  ],
                ),
              ),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Container(
                    width: 60,
                    height: 60,

                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),

                    child: const Icon(
                      Icons.home_work_rounded,
                      color: AppColors.primaryGreen,
                      size: 30,
                    ),
                  ),

                  const SizedBox(height: 16),

                  const Text(
                    'RT 03 RW 011',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 4),

                  const Text(
                    'Aren Jaya, Bekasi Timur',
                    style: TextStyle(
                      color: Color(0xFFB7E4C7),
                    ),
                  ),
                ],
              ),
            ),

            Container(
              color: Colors.white,

              child: TabBar(
                controller: _tabController,

                indicatorColor: AppColors.primaryGreen,

                labelColor: AppColors.primaryGreen,

                unselectedLabelColor: Colors.grey,

                tabs: const [
                  Tab(text: 'Masuk'),
                  Tab(text: 'Daftar'),
                ],
              ),
            ),

            Expanded(
              child: TabBarView(
                controller: _tabController,

                children: [
                  buildLogin(),
                  buildRegister(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =========================================================
  // LOGIN UI
  // =========================================================

  Widget buildLogin() {

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),

      child: Column(
        children: [

          const SizedBox(height: 20),

          inputField(
            controller: loginEmailController,
            label: 'Email',
            icon: Icons.email_outlined,
          ),

          const SizedBox(height: 16),

          inputField(
            controller: loginPasswordController,
            label: 'Password',
            icon: Icons.lock_outline,
            obscure: obscureLogin,

            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  obscureLogin = !obscureLogin;
                });
              },

              icon: Icon(
                obscureLogin
                    ? Icons.visibility_off
                    : Icons.visibility,
              ),
            ),
          ),

          const SizedBox(height: 24),

          submitButton(
            label: 'LOGIN',
            icon: Icons.login,
            loading: loadingLogin,
            onTap: login,
          ),
        ],
      ),
    );
  }

  // =========================================================
  // REGISTER UI
  // =========================================================

  Widget buildRegister() {

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),

      child: Column(
        children: [

          inputField(
            controller: regNamaController,
            label: 'Nama Lengkap',
            icon: Icons.person_outline,
          ),

          const SizedBox(height: 16),

          inputField(
            controller: regNikController,
            label: 'NIK',
            icon: Icons.credit_card,
          ),

          const SizedBox(height: 16),

          inputField(
            controller: regEmailController,
            label: 'Email',
            icon: Icons.email_outlined,
          ),

          const SizedBox(height: 16),

          inputField(
            controller: regPasswordController,
            label: 'Password',
            icon: Icons.lock_outline,
            obscure: obscureRegister,

            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  obscureRegister = !obscureRegister;
                });
              },

              icon: Icon(
                obscureRegister
                    ? Icons.visibility_off
                    : Icons.visibility,
              ),
            ),
          ),

          const SizedBox(height: 16),

          inputField(
            controller: regNoHpController,
            label: 'No HP',
            icon: Icons.phone,
          ),

          const SizedBox(height: 16),

          inputField(
            controller: regAlamatController,
            label: 'Alamat',
            icon: Icons.home_outlined,
            maxLines: 3,
          ),

          const SizedBox(height: 24),

          submitButton(
            label: 'REGISTER',
            icon: Icons.app_registration,
            loading: loadingRegister,
            onTap: register,
          ),
        ],
      ),
    );
  }

  // =========================================================
  // INPUT
  // =========================================================

  Widget inputField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscure = false,
    int maxLines = 1,
    Widget? suffixIcon,
  }) {

    return TextField(
      controller: controller,
      obscureText: obscure,
      maxLines: maxLines,

      decoration: InputDecoration(
        labelText: label,

        prefixIcon: Icon(
          icon,
          color: AppColors.primaryGreen,
        ),

        suffixIcon: suffixIcon,

        filled: true,
        fillColor: Colors.white,

        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  // =========================================================
  // BUTTON
  // =========================================================

  Widget submitButton({
    required String label,
    required IconData icon,
    required bool loading,
    required VoidCallback onTap,
  }) {

    return SizedBox(
      width: double.infinity,
      height: 55,

      child: ElevatedButton.icon(
        onPressed: loading ? null : onTap,

        icon: loading
            ? const SizedBox(
                width: 20,
                height: 20,

                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              )
            : Icon(icon),

        label: Text(label),

        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryGreen,
          foregroundColor: Colors.white,

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}