import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';
import '../../models/models.dart';
import '../../services/firestore_service.dart';

class AdminDataWargaScreen extends StatefulWidget {
  const AdminDataWargaScreen({super.key});

  @override
  State<AdminDataWargaScreen> createState() => _AdminDataWargaScreenState();
}

class _AdminDataWargaScreenState extends State<AdminDataWargaScreen> {
  final FirestoreService _db = FirestoreService();
  String _query = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgGreen,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _query = v.toLowerCase()),
              decoration: InputDecoration(
                hintText: 'Cari nama warga...',
                prefixIcon: const Icon(Icons.search_rounded, color: AppColors.primaryGreen),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<UserModel>>(
              stream: _db.streamSemuaWarga(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Terjadi kesalahan: ${snapshot.error}'));
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
                }
                var items = snapshot.data!;
                if (_query.isNotEmpty) {
                  items = items.where((u) => u.nama.toLowerCase().contains(_query) || u.nik.contains(_query)).toList();
                }
                if (items.isEmpty) {
                  return const Center(
                    child: Text('Belum ada warga terdaftar', style: TextStyle(color: AppColors.textGrey, fontSize: 14)),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                  itemCount: items.length,
                  itemBuilder: (context, i) {
                    final u = items[i];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: const BoxDecoration(color: AppColors.lightGreen, shape: BoxShape.circle),
                            child: Center(
                              child: Text(
                                u.nama.isNotEmpty ? u.nama[0].toUpperCase() : '?',
                                style: const TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.w800, fontSize: 16),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(u.nama, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: AppColors.textDark)),
                                const SizedBox(height: 2),
                                Text('NIK: ${u.nik}', style: const TextStyle(fontSize: 12, color: AppColors.textGrey)),
                                Text(u.noHp, style: const TextStyle(fontSize: 12, color: AppColors.textGrey)),
                                if (u.alamat.isNotEmpty)
                                  Text(u.alamat, style: const TextStyle(fontSize: 11.5, color: AppColors.textGrey), maxLines: 1, overflow: TextOverflow.ellipsis),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
