import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../login_screen.dart';
import '../../utils/app_colors.dart';
import '../../services/firestore_service.dart';

import 'admin_pengumuman_screen.dart';
import 'admin_kegiatan_screen.dart';
import 'admin_galeri_screen.dart';
import 'admin_umkm_screen.dart';
import 'admin_profil_rt_screen.dart';
import 'admin_pengaduan_screen.dart';
import 'admin_permohonan_surat_screen.dart';
import 'admin_pembayaran_screen.dart';
import 'admin_data_warga_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  int _currentIndex = 0;
  String _namaAdmin = 'Admin';

  @override
  void initState() {
    super.initState();
    _loadNamaAdmin();
  }

  Future<void> _loadNamaAdmin() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (mounted && doc.exists) {
      setState(() {
        _namaAdmin = doc.data()?['nama'] ?? 'Admin';
      });
    }
  }

  final List<_AdminMenu> _menus = [
    _AdminMenu(icon: Icons.dashboard_rounded, label: 'Dashboard'),
    _AdminMenu(icon: Icons.campaign_rounded, label: 'Pengumuman'),
    _AdminMenu(icon: Icons.photo_library_rounded, label: 'Galeri'),
    _AdminMenu(icon: Icons.event_rounded, label: 'Kegiatan'),
    _AdminMenu(icon: Icons.report_problem_rounded, label: 'Pengaduan'),
    _AdminMenu(icon: Icons.description_rounded, label: 'Surat'),
    _AdminMenu(icon: Icons.storefront_rounded, label: 'UMKM'),
    _AdminMenu(icon: Icons.location_city_rounded, label: 'Profil RT'),
    _AdminMenu(icon: Icons.people_rounded, label: 'Data Warga'),
    _AdminMenu(icon: Icons.payment_rounded, label: 'Pembayaran'),
  ];

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgGreen,
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Admin Panel',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Selamat datang, $_namaAdmin',
                style: const TextStyle(color: Color(0xFFB7E4C7), fontSize: 11)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded, color: Colors.white),
            tooltip: 'Logout',
            onPressed: _logout,
          ),
        ],
      ),
      body: _buildBody(),
      bottomNavigationBar: _currentIndex > 0
          ? null
          : null,
    );
  }

  Widget _buildBody() {
    if (_currentIndex == 0) return _buildDashboardHome();
    return _buildMenuDetail(_menus[_currentIndex].label);
  }

  Widget _buildDashboardHome() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Welcome Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1B4332), Color(0xFF2D6A4F)],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Selamat Datang, $_namaAdmin',
                    style: const TextStyle(
                        color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                const Text('Kelola RT 03 RW 011 dengan mudah',
                    style: TextStyle(color: Color(0xFFB7E4C7), fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          FutureBuilder<Map<String, int>>(
            future: FirestoreService().getDashboardStats(),
            builder: (context, snapshot) {
              final stats = snapshot.data;
              return Row(
                children: [
                  _statCard(Icons.campaign_rounded, '${stats?['pengumuman'] ?? '-'}', 'Pengumuman'),
                  const SizedBox(width: 10),
                  _statCard(Icons.event_rounded, '${stats?['kegiatan'] ?? '-'}', 'Agenda'),
                  const SizedBox(width: 10),
                  _statCard(Icons.store_rounded, '${stats?['umkm'] ?? '-'}', 'UMKM Aktif'),
                  const SizedBox(width: 10),
                  _statCard(Icons.report_problem_rounded, '${stats?['pengaduan_baru'] ?? '-'}', 'Pengaduan Baru'),
                ],
              );
            },
          ),
          const SizedBox(height: 20),
          const Text('Menu Admin',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87)),
          const SizedBox(height: 12),
          // Grid Menu
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.9,
            ),
            itemCount: _menus.length,
            itemBuilder: (context, index) {
              return _AdminMenuCard(
                menu: _menus[index],
                onTap: () => setState(() => _currentIndex = index),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _statCard(IconData icon, String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Column(
          children: [
            Icon(icon, color: AppColors.accentGreen, size: 18),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.darkGreen)),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(fontSize: 9, color: AppColors.textGrey), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

Widget _buildMenuDetail(String label) {

  Widget page;

  if (label == 'Kegiatan') {
    page = const AdminKegiatanScreen();
  } else if (label == 'Pengumuman') {
    page = const AdminPengumumanScreen();
  } else if (label == 'Galeri') {
    page = const AdminGaleriScreen();
  } else if (label == 'UMKM') {
    page = const AdminUmkmScreen();
  } else if (label == 'Profil RT') {
    page = const AdminProfilRtScreen();
  } else if (label == 'Pengaduan') {
    page = const AdminPengaduanScreen();
  } else if (label == 'Surat') {
    page = const AdminPermohonanSuratScreen();
  } else if (label == 'Pembayaran') {
    page = const AdminPembayaranScreen();
  } else if (label == 'Data Warga') {
    page = const AdminDataWargaScreen();
  } else {
    page = Center(
      child: Text(
        '$label belum dibuat',
      ),
    );
  }

  return Column(
    children: [

      Container(
        width: double.infinity,
        color: AppColors.primaryGreen,
        child: SafeArea(
          bottom: false,
          child: Row(
            children: [

              IconButton(
                icon: const Icon(
                  Icons.arrow_back_rounded,
                  color: Colors.white,
                ),
                onPressed: () {
                  setState(() {
                    _currentIndex = 0;
                  });
                },
              ),

              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

Expanded(
  child: page,
),
],
);
}

}

class _AdminMenu {
  final IconData icon;
  final String label;
  const _AdminMenu({required this.icon, required this.label});
}

class _AdminMenuCard extends StatelessWidget {
  final _AdminMenu menu;
  final VoidCallback onTap;

  const _AdminMenuCard({required this.menu, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.primaryGreen.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(menu.icon, color: AppColors.primaryGreen, size: 26),
            ),
            const SizedBox(height: 8),
            Text(menu.label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w600, color: Colors.black87)),
          ],
        ),
      ),
    );
  }
}