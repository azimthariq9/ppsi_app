// ============================================================
// lib/services/firestore_service.dart
// CRUD lengkap untuk semua koleksi Firestore
// ============================================================

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/models.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ════════════════════════════════════════════════════════════════════════
  // USERS
  // ════════════════════════════════════════════════════════════════════════

  /// Simpan data user ke Firestore saat register
  Future<void> createUser(UserModel user) async {
    await _db.collection('users').doc(user.id).set(user.toMap());
  }

  /// Ambil data user berdasarkan UID
  Future<UserModel?> getUser(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromFirestore(doc);
  }

  /// Stream semua warga (untuk admin kelola warga)
  Stream<List<UserModel>> streamSemuaWarga() {
    return _db
        .collection('users')
        .where('role', isEqualTo: 'warga')
        .orderBy('created_at', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(UserModel.fromFirestore).toList());
  }

  // ════════════════════════════════════════════════════════════════════════
  // PROFIL RT
  // ════════════════════════════════════════════════════════════════════════

  /// Ambil data profil RT (1 dokumen)
  Future<ProfilRTModel?> getProfilRT() async {
    final doc = await _db.collection('rt_info').doc('main').get();
    if (!doc.exists) return null;
    return ProfilRTModel.fromFirestore(doc);
  }

  /// Update data profil RT — hanya admin
  Future<void> updateProfilRT(Map<String, dynamic> data) async {
    await _db.collection('rt_info').doc('main').set(data, SetOptions(merge: true));
  }

  // ════════════════════════════════════════════════════════════════════════
  // PENGUMUMAN
  // ════════════════════════════════════════════════════════════════════════

  /// Stream semua pengumuman (realtime, urut terbaru)
  Stream<List<PengumumanModel>> streamPengumuman() {
    return _db
        .collection('pengumuman')
        .orderBy('created_at', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(PengumumanModel.fromFirestore).toList());
  }

  /// Buat pengumuman baru
  Future<void> createPengumuman(PengumumanModel p) async {
    await _db.collection('pengumuman').add(p.toMap());
  }

  /// Update pengumuman
  Future<void> updatePengumuman(String id, Map<String, dynamic> data) async {
    await _db.collection('pengumuman').doc(id).update(data);
  }

  /// Hapus pengumuman
  Future<void> deletePengumuman(String id) async {
    await _db.collection('pengumuman').doc(id).delete();
  }

  // ════════════════════════════════════════════════════════════════════════
  // KEGIATAN
  // ════════════════════════════════════════════════════════════════════════

  /// Stream semua kegiatan (realtime)
  Stream<List<KegiatanModel>> streamKegiatan() {
    return _db
        .collection('kegiatan')
        .orderBy('tanggal', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(KegiatanModel.fromFirestore).toList());
  }

  /// Kegiatan mendatang saja
  Stream<List<KegiatanModel>> streamKegiatanMendatang() {
    return _db
        .collection('kegiatan')
        .where('tanggal', isGreaterThanOrEqualTo: Timestamp.fromDate(DateTime.now()))
        .orderBy('tanggal')
        .limit(5)
        .snapshots()
        .map((snap) => snap.docs.map(KegiatanModel.fromFirestore).toList());
  }

  Future<void> createKegiatan(KegiatanModel k) async {
    await _db.collection('kegiatan').add(k.toMap());
  }

  Future<void> updateKegiatan(String id, Map<String, dynamic> data) async {
    await _db.collection('kegiatan').doc(id).update(data);
  }

  Future<void> deleteKegiatan(String id) async {
    await _db.collection('kegiatan').doc(id).delete();
  }

  // ════════════════════════════════════════════════════════════════════════
  // PENGADUAN
  // ════════════════════════════════════════════════════════════════════════

  /// Stream pengaduan milik warga tertentu
  Stream<List<PengaduanModel>> streamPengaduanByUser(String userId) {
    return _db
        .collection('pengaduan')
        .where('user_id', isEqualTo: userId)
        .orderBy('created_at', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(PengaduanModel.fromFirestore).toList());
  }

  /// Stream semua pengaduan (untuk admin)
  Stream<List<PengaduanModel>> streamSemuaPengaduan({String? statusFilter}) {
    Query query = _db.collection('pengaduan').orderBy('created_at', descending: true);
    if (statusFilter != null) {
      query = query.where('status', isEqualTo: statusFilter);
    }
    return query.snapshots().map((snap) => snap.docs.map(PengaduanModel.fromFirestore).toList());
  }

  Future<void> createPengaduan(PengaduanModel p) async {
    await _db.collection('pengaduan').add(p.toMap());
  }

  /// Admin mengubah status pengaduan
  Future<void> updateStatusPengaduan(String id, String status, {String? catatan}) async {
    await _db.collection('pengaduan').doc(id).update({
      'status': status,
      if (catatan != null) 'catatan_admin': catatan,
      'updated_at': Timestamp.now(),
    });
  }

  // ════════════════════════════════════════════════════════════════════════
  // PERMOHONAN SURAT
  // ════════════════════════════════════════════════════════════════════════

  Stream<List<PermohonanSuratModel>> streamSuratByUser(String userId) {
    return _db
        .collection('permohonan_surat')
        .where('user_id', isEqualTo: userId)
        .orderBy('created_at', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(PermohonanSuratModel.fromFirestore).toList());
  }

  Stream<List<PermohonanSuratModel>> streamSemuaSurat({String? statusFilter}) {
    Query query = _db.collection('permohonan_surat').orderBy('created_at', descending: true);
    if (statusFilter != null) {
      query = query.where('status', isEqualTo: statusFilter);
    }
    return query.snapshots().map((snap) => snap.docs.map(PermohonanSuratModel.fromFirestore).toList());
  }

  Future<void> createPermohonanSurat(PermohonanSuratModel s) async {
    await _db.collection('permohonan_surat').add(s.toMap());
  }

  Future<void> updateStatusSurat(String id, String status, {String? catatan, String? fileUrl}) async {
    await _db.collection('permohonan_surat').doc(id).update({
      'status': status,
      if (catatan != null) 'catatan_admin': catatan,
      if (fileUrl != null) 'file_surat_url': fileUrl,
      'updated_at': Timestamp.now(),
    });
  }

  // ════════════════════════════════════════════════════════════════════════
  // PEMBAYARAN
  // ════════════════════════════════════════════════════════════════════════

  /// Stream riwayat pembayaran warga
  Stream<List<PembayaranModel>> streamPembayaranByUser(String userId) {
    return _db
        .collection('pembayaran')
        .where('user_id', isEqualTo: userId)
        .orderBy('created_at', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(PembayaranModel.fromFirestore).toList());
  }

  /// Status pembayaran bulan ini
  Future<PembayaranModel?> getPembayaranBulanIni(String userId, String bulan) async {
    final snap = await _db
        .collection('pembayaran')
        .where('user_id', isEqualTo: userId)
        .where('bulan', isEqualTo: bulan)
        .where('jenis_iuran', isEqualTo: 'Iuran Bulanan')
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return null;
    return PembayaranModel.fromFirestore(snap.docs.first);
  }

  /// Stream semua pembayaran untuk admin
  Stream<List<PembayaranModel>> streamSemuaPembayaran({String? statusFilter, String? bulanFilter}) {
    Query query = _db.collection('pembayaran').orderBy('created_at', descending: true);
    if (statusFilter != null) query = query.where('status', isEqualTo: statusFilter);
    if (bulanFilter != null) query = query.where('bulan', isEqualTo: bulanFilter);
    return query.snapshots().map((snap) => snap.docs.map(PembayaranModel.fromFirestore).toList());
  }

  /// Warga submit bukti bayar
  Future<void> createPembayaran(PembayaranModel p) async {
    await _db.collection('pembayaran').add(p.toMap());
  }

  /// Admin verifikasi pembayaran
  Future<void> verifikasiPembayaran(String id, String adminId) async {
    await _db.collection('pembayaran').doc(id).update({
      'status': 'lunas',
      'verified_by_id': adminId,
      'tanggal_bayar': Timestamp.now(),
    });
  }

  Future<void> tolakPembayaran(String id) async {
    await _db.collection('pembayaran').doc(id).update({
      'status': 'belum',
    });
  }

  // ════════════════════════════════════════════════════════════════════════
  // GALERI
  // ════════════════════════════════════════════════════════════════════════

  Stream<List<GaleriModel>> streamGaleri() {
    return _db
        .collection('galeri')
        .orderBy('created_at', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(GaleriModel.fromFirestore).toList());
  }

  Future<void> createGaleri(GaleriModel g) async {
    await _db.collection('galeri').add(g.toMap());
  }

  Future<void> deleteGaleri(String id) async {
    await _db.collection('galeri').doc(id).delete();
  }

  // ════════════════════════════════════════════════════════════════════════
  // UMKM
  // ════════════════════════════════════════════════════════════════════════

  Stream<List<UMKMModel>> streamUMKM() {
    return _db
        .collection('umkm')
        .where('is_active', isEqualTo: true)
        .orderBy('created_at', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(UMKMModel.fromFirestore).toList());
  }

  Stream<List<UMKMModel>> streamUMKMByOwner(String userId) {
    return _db
        .collection('umkm')
        .where('pemilik_id', isEqualTo: userId)
        .snapshots()
        .map((snap) => snap.docs.map(UMKMModel.fromFirestore).toList());
  }

  Future<void> createUMKM(UMKMModel u) async {
    await _db.collection('umkm').add(u.toMap());
  }

  /// Buat UMKM dan kembalikan ID dokumennya (untuk upload foto setelahnya)
  Future<String> createUMKMAndGetId(UMKMModel u) async {
    final docRef = await _db.collection('umkm').add(u.toMap());
    return docRef.id;
  }

  Future<void> updateUMKM(String id, Map<String, dynamic> data) async {
    await _db.collection('umkm').doc(id).update(data);
  }

  Future<void> deleteUMKM(String id) async {
    await _db.collection('umkm').doc(id).update({'is_active': false});
  }

  // ════════════════════════════════════════════════════════════════════════
  // RINGKASAN DASHBOARD (untuk home screen)
  // ════════════════════════════════════════════════════════════════════════

  Future<Map<String, int>> getDashboardStats() async {
    final results = await Future.wait([
      _db.collection('pengumuman').count().get(),
      _db.collection('kegiatan').where('tanggal', isGreaterThan: Timestamp.now()).count().get(),
      _db.collection('umkm').where('is_active', isEqualTo: true).count().get(),
      _db.collection('pengaduan').where('status', isEqualTo: 'menunggu').count().get(),
    ]);

    return {
      'pengumuman': results[0].count ?? 0,
      'kegiatan': results[1].count ?? 0,
      'umkm': results[2].count ?? 0,
      'pengaduan_baru': results[3].count ?? 0,
    };
  }
}
