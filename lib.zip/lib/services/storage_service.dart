// ============================================================
// lib/services/storage_service.dart
// Upload & hapus file di Firebase Storage
// ============================================================

import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final _picker = ImagePicker();
  final _uuid = const Uuid();

  // ─── PILIH GAMBAR ────────────────────────────────────────────────────────

  Future<File?> pickImage({ImageSource source = ImageSource.gallery}) async {
    final picked = await _picker.pickImage(
      source: source,
      imageQuality: 75,   // Compress untuk hemat storage
      maxWidth: 1080,
    );
    if (picked == null) return null;
    return File(picked.path);
  }

  // ─── UPLOAD FOTO PROFIL ──────────────────────────────────────────────────
  // Path: /profil/{userId}.jpg

  Future<String> uploadFotoProfil(String userId, File file) async {
    final ref = _storage.ref('profil/$userId.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return await ref.getDownloadURL();
  }

  // ─── UPLOAD GAMBAR PENGUMUMAN ────────────────────────────────────────────
  // Path: /pengumuman/{uuid}.jpg

  Future<String> uploadGambarPengumuman(File file) async {
    final id = _uuid.v4();
    final ref = _storage.ref('pengumuman/$id.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return await ref.getDownloadURL();
  }

  // ─── UPLOAD GAMBAR KEGIATAN ──────────────────────────────────────────────

  Future<String> uploadGambarKegiatan(File file) async {
    final id = _uuid.v4();
    final ref = _storage.ref('kegiatan/$id.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return await ref.getDownloadURL();
  }

  // ─── UPLOAD FOTO PENGADUAN ───────────────────────────────────────────────
  // Path: /pengaduan/{userId}/{uuid}.jpg

  Future<String> uploadFotoPengaduan(String userId, File file) async {
    final id = _uuid.v4();
    final ref = _storage.ref('pengaduan/$userId/$id.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return await ref.getDownloadURL();
  }

  // ─── UPLOAD BUKTI PEMBAYARAN ─────────────────────────────────────────────
  // Path: /pembayaran/{userId}/{bulan}.jpg

  Future<String> uploadBuktiBayar(String userId, String bulan, File file) async {
    final ref = _storage.ref('pembayaran/$userId/$bulan.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return await ref.getDownloadURL();
  }

  // Upload dengan progress callback
  Future<String> uploadBuktiBayarWithProgress(
    String userId,
    String bulan,
    File file, {
    Function(double)? onProgress,
  }) async {
    final ref = _storage.ref('pembayaran/$userId/$bulan.jpg');
    final task = ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));

    task.snapshotEvents.listen((event) {
      final progress = event.bytesTransferred / event.totalBytes;
      onProgress?.call(progress);
    });

    await task;
    return await ref.getDownloadURL();
  }

  // ─── UPLOAD GAMBAR GALERI ────────────────────────────────────────────────

  Future<String> uploadGambarGaleri(File file) async {
    final id = _uuid.v4();
    final ref = _storage.ref('galeri/$id.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return await ref.getDownloadURL();
  }

  // ─── UPLOAD FOTO UMKM ───────────────────────────────────────────────────

  Future<String> uploadFotoUMKM(String umkmId, File file) async {
    final ref = _storage.ref('umkm/$umkmId.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return await ref.getDownloadURL();
  }

  // ─── HAPUS FILE ──────────────────────────────────────────────────────────

  Future<void> deleteFile(String downloadUrl) async {
    try {
      final ref = _storage.refFromURL(downloadUrl);
      await ref.delete();
    } catch (_) {
      // Abaikan jika file tidak ada
    }
  }
}
